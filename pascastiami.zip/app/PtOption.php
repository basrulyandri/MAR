<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PtOption extends Model
{
    protected $fillable = ['option_key','option_value'];
}
